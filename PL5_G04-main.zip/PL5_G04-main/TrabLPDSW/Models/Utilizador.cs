public class Utilizador
{
    public string Nome { get; set; }
    public string Email { get; set; }
    public byte[]? Fotografia { get; set; } 
}